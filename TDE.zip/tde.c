
//GABRIEL DE JESUS PEREIRA DA SILVA(8161800)
//DANIEL PERFETTI SANT� (2423187)
//JO�O VITOR ROCHA CARDOSO (6156498)
//LEANDRO NUNES DOS SANTOS (1190985)
//VITOR AMORIM TARTARI (3492050)
//VITOR OLIVEIRA CHRISTOVAM (2362780)



#include <stdio.h>
#include <strings.h>
#define LINHA 90

    /*ponto e virgula*/
    void remover(char *linha) {
    char *posicao;
    while ((posicao = strchr(linha, ';')) != NULL) {
        *posicao = ' ';
    }
}

int main() {
    FILE *SP;
    FILE *RJ;
    FILE *MG;
    FILE *ES;
    FILE *estimativa2012;
    FILE *estimativa2021;
    FILE *estimativa;

    int num, num2;
    char linha[185][90];

    do {
        printf("---------------------------------------");
        printf("\nEstimativa de Populacao ano 2012 e 2021\n\n");
        printf("1-Estimativa das Cidades\n");
        printf("2-Estimativa de 2012\n");
        printf("3-Estimativa de 2021\n");
        printf("4-Estimativa da Regiao Sudeste\n");
        printf("\n5-Sair\n");
        printf("---------------------------------------");
        printf("\n");

        printf("Digite a opcao: ");
        scanf("%i", &num);
        printf("\n");

        /*1-Estimativa das Cidades*/
        switch (num) {
            case 1:
                system("cls");
                printf("1-SAO PAULO\n");
                printf("2-RIO DE JANEIRO\n");
                printf("3-MINAS GERAIS\n");
                printf("4-ESPIRITO SANTO\n");
                printf("\n");

                printf("Digite um numero equivalente ao estado: ");
                scanf("%i", &num2);
                printf("\n");

                    switch (num2) {
    /*SP*/
    case 1: SP = fopen("SP.csv", " r ");
                while (fgets(linha, LINHA, SP) != NULL) {
                remover(linha);
                printf("%s", linha);
            }
            fclose(SP);
        break;
    /*RJ*/
    case 2: RJ = fopen("RJ.csv", " r ");
                while (fgets(linha, LINHA, RJ) != NULL) {
                remover(linha);
                printf("%s", linha);
            }
            fclose(RJ);
        break;
    /*MG*/
    case 3: MG = fopen("MG.csv", " r ");
                while (fgets(linha, LINHA, MG) != NULL) {
                remover(linha);
                printf("%s", linha);
            }
            fclose(MG);
        break;
    /*ES*/
    case 4: ES = fopen("ES.csv", " r ");
                while (fgets(linha, LINHA, ES) != NULL) {
                remover(linha);
                printf("%s", linha);
            }
            fclose(ES);
        break;

    default: printf("Estado Incorreto\n");
        break;
    }

    break;
            /*estimativa 2012*/
            case 2:
                system("cls");
                estimativa2012 = fopen("estimativa_2012.csv", "r");
                    while (fgets(linha, LINHA, estimativa2012) != NULL) {
                    remover(linha);
                    printf("%s", linha);
                }
                fclose(estimativa2012);
                break;

            /*estimativa 2021*/
            case 3:
                system("cls");
                estimativa2021 = fopen("estimativa_2021.csv", "r");
                    while (fgets(linha, LINHA, estimativa2021) != NULL) {
                    remover(linha);
                    printf("%s", linha);
                }
                fclose(estimativa2021);
                break;

            /*estimativa sudeste*/
            case 4:
                system("cls");
                estimativa = fopen("estimativa.csv", "r");
                    while (fgets(linha, LINHA, estimativa) != NULL) {
                    remover(linha);
                    printf("%s", linha);
                }
                fclose(estimativa);
                break;

            case 5:
                printf("Obrigado por usar esse programa!\n");
                return 1;
        }
    } while (num != 1 || num != 2 || num != 3 || num != 4);
    return 0;
}
